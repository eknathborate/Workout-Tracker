package com.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.entity.Workout;
import com.repository.WorkoutRepository;

@Service
public class WorkoutService {
	
	@Autowired
	private WorkoutRepository workoutRepository;
	
	public Workout saveWorkout(Workout workout) {
		return workoutRepository.save(workout);
	}
	
	public List<Workout> getUserWorkouts(Long userId){
		return workoutRepository.findByUserId(userId);
	}
}
