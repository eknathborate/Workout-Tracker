package com.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.entity.User;
import com.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	public User registerUser(User user) {
		return userRepository.save(user);
	}
	public Optional<User> getUserByEmail(String email){
		return userRepository.findByEmail(email);
	}
}
