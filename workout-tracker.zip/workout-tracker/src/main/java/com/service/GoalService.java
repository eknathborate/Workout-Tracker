package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Goal;
import com.repository.GoalRepository;

@Service
public class GoalService {
	@Autowired
	private GoalRepository goalRepository;
	public Goal saveGoal(Goal goal) {
		return goalRepository.save(goal);
	}
}
