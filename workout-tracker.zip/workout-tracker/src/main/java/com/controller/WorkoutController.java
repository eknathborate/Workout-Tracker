package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Workout;
import com.service.WorkoutService;

@RestController
@RequestMapping("/api/workouts")
public class WorkoutController {
	
	@Autowired
	private WorkoutService workoutService;
	
	@PostMapping
	public ResponseEntity<Workout> addWorkout(@RequestBody Workout workout){
		return ResponseEntity.ok(workoutService.saveWorkout(workout));
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<List<Workout>> getWorkouts(@PathVariable Long userId) {
        return ResponseEntity.ok(workoutService.getUserWorkouts(userId));
    }
}